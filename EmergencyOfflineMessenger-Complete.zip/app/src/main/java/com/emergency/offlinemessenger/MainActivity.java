package com.emergency.offlinemessenger;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private BluetoothAdapter bluetoothAdapter;
    private ArrayAdapter<String> pairedDevicesArrayAdapter;
    private ArrayAdapter<String> discoveredDevicesArrayAdapter;
    private ArrayList<BluetoothDevice> discoveredDevices;
    private BluetoothService bluetoothService;

    private ListView pairedListView, discoveredListView;
    private Button enableBluetoothBtn, scanBtn, chatBtn, sosBtn;
    private EditText messageEditText;
    private TextView chatTextView, statusTextView, connectedDevicesTextView;
    private Button sendBtn;
    private Spinner messageTemplateSpinner;

    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_BLUETOOTH_PERMISSION = 2;
    private static final int REQUEST_LOCATION_PERMISSION = 3;

    private LocationManager locationManager;
    private Vibrator vibrator;

    // Emergency message templates
    private String[] emergencyTemplates = {
        "Custom message...",
        "🆘 EMERGENCY: Need immediate help at my location",
        "🏥 MEDICAL: Medical emergency, need first aid", 
        "🔥 FIRE: Fire emergency at my location",
        "🚗 ACCIDENT: Vehicle accident, need assistance",
        "🧭 LOST: Lost and need directions/rescue",
        "✅ SAFE: I am safe and accounted for",
        "🏠 SHELTER: Need emergency shelter",
        "📦 SUPPLY: Need food/water/medical supplies",
        "🏃 EVACUATION: Evacuation needed in this area",
        "🟢 ALL CLEAR: Area is safe, danger has passed"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupBluetooth();
        setupClickListeners();
        checkPermissions();
        setupLocationManager();
        setupVibrator();
    }

    private void initializeViews() {
        enableBluetoothBtn = findViewById(R.id.enableBluetoothBtn);
        scanBtn = findViewById(R.id.scanBtn);
        chatBtn = findViewById(R.id.chatBtn);
        sosBtn = findViewById(R.id.sosBtn);
        pairedListView = findViewById(R.id.pairedDevicesListView);
        discoveredListView = findViewById(R.id.discoveredDevicesListView);
        messageEditText = findViewById(R.id.messageEditText);
        chatTextView = findViewById(R.id.chatTextView);
        sendBtn = findViewById(R.id.sendBtn);
        statusTextView = findViewById(R.id.statusTextView);
        connectedDevicesTextView = findViewById(R.id.connectedDevicesTextView);
        messageTemplateSpinner = findViewById(R.id.messageTemplateSpinner);

        discoveredDevices = new ArrayList<>();

        pairedDevicesArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        discoveredDevicesArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);

        pairedListView.setAdapter(pairedDevicesArrayAdapter);
        discoveredListView.setAdapter(discoveredDevicesArrayAdapter);

        // Setup message template spinner
        ArrayAdapter<String> templateAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, emergencyTemplates);
        templateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        messageTemplateSpinner.setAdapter(templateAdapter);

        messageTemplateSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    messageEditText.setText(emergencyTemplates[position]);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        updateStatus("App initialized - Enable Bluetooth to start");
    }

    private void setupBluetooth() {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth not supported on this device", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        bluetoothService = new BluetoothService(this, new BluetoothService.BluetoothHandler() {
            @Override
            public void onMessageReceived(String message) {
                runOnUiThread(() -> {
                    String timestamp = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                    chatTextView.append("[" + timestamp + "] Received: " + message + "\n\n");

                    // Vibrate for received emergency messages
                    if (message.contains("🆘") || message.contains("EMERGENCY") || message.contains("SOS")) {
                        vibrateSOS();
                    }
                });
            }

            @Override
            public void onConnectionStateChanged(int state) {
                runOnUiThread(() -> {
                    switch (state) {
                        case BluetoothService.STATE_CONNECTED:
                            updateStatus("Connected to mesh network");
                            updateConnectedDevices(1);
                            Toast.makeText(MainActivity.this, "Connected to emergency network!", Toast.LENGTH_SHORT).show();
                            break;
                        case BluetoothService.STATE_CONNECTING:
                            updateStatus("Connecting to network...");
                            break;
                        case BluetoothService.STATE_LISTEN:
                            updateStatus("Listening for connections...");
                            break;
                        case BluetoothService.STATE_NONE:
                            updateStatus("Disconnected from network");
                            updateConnectedDevices(0);
                            break;
                    }
                });
            }
        });
    }

    private void setupClickListeners() {
        enableBluetoothBtn.setOnClickListener(v -> {
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            } else {
                loadPairedDevices();
                updateStatus("Bluetooth enabled - Ready for emergency communication");
            }
        });

        scanBtn.setOnClickListener(v -> startDeviceDiscovery());

        chatBtn.setOnClickListener(v -> {
            bluetoothService.start();
            updateStatus("Emergency network server started - Other devices can now connect");
            Toast.makeText(this, "Emergency network active", Toast.LENGTH_SHORT).show();
        });

        sosBtn.setOnClickListener(v -> sendSOSMessage());

        sendBtn.setOnClickListener(v -> {
            String message = messageEditText.getText().toString().trim();
            if (!message.isEmpty()) {
                sendMessage(message);
                messageEditText.setText("");
            }
        });

        pairedListView.setOnItemClickListener((parent, view, position, id) -> {
            String deviceInfo = pairedDevicesArrayAdapter.getItem(position);
            if (deviceInfo != null && !deviceInfo.equals("No paired devices found")) {
                String address = deviceInfo.substring(deviceInfo.length() - 17);
                BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);
                bluetoothService.connect(device);
                updateStatus("Connecting to " + device.getName());
            }
        });

        discoveredListView.setOnItemClickListener((parent, view, position, id) -> {
            BluetoothDevice device = discoveredDevices.get(position);
            bluetoothService.connect(device);
            updateStatus("Connecting to " + device.getName());
        });
    }

    private void checkPermissions() {
        String[] permissions = {
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.VIBRATE
        };

        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, permissions, REQUEST_BLUETOOTH_PERMISSION);
                return;
            }
        }
    }

    private void setupLocationManager() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
    }

    private void setupVibrator() {
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
    }

    private void loadPairedDevices() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        pairedDevicesArrayAdapter.clear();

        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                pairedDevicesArrayAdapter.add(device.getName() + "\n" + device.getAddress());
            }
        } else {
            pairedDevicesArrayAdapter.add("No paired devices found");
        }
    }

    private void startDeviceDiscovery() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        if (bluetoothAdapter.isDiscovering()) {
            bluetoothAdapter.cancelDiscovery();
        }

        discoveredDevicesArrayAdapter.clear();
        discoveredDevices.clear();

        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(discoveryReceiver, filter);

        bluetoothAdapter.startDiscovery();
        updateStatus("Scanning for emergency devices...");
        Toast.makeText(this, "Scanning for emergency devices...", Toast.LENGTH_SHORT).show();
    }

    private void sendMessage(String message) {
        String timestamp = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        String locationInfo = getCurrentLocation();
        String fullMessage = message;

        if (!locationInfo.isEmpty() && (message.contains("🆘") || message.contains("EMERGENCY") || message.contains("SOS"))) {
            fullMessage += "\n📍 Location: " + locationInfo;
        }

        bluetoothService.write(fullMessage.getBytes());
        chatTextView.append("[" + timestamp + "] Sent: " + fullMessage + "\n\n");
        updateStatus("Message sent to network");
    }

    private void sendSOSMessage() {
        new AlertDialog.Builder(this)
            .setTitle("⚠️ SEND SOS EMERGENCY ALERT")
            .setMessage("This will broadcast an emergency SOS message to all connected devices in the mesh network.\n\nAre you sure you want to send this emergency alert?")
            .setPositiveButton("SEND SOS", (dialog, which) -> {
                String sosMessage = "🆘 SOS EMERGENCY ALERT 🆘\n" +
                    "I NEED IMMEDIATE HELP!\n" +
                    "Time: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

                sendMessage(sosMessage);
                vibrateSOS();
                updateStatus("🆘 EMERGENCY SOS SENT TO ALL DEVICES");
                Toast.makeText(this, "🆘 SOS EMERGENCY ALERT SENT!", Toast.LENGTH_LONG).show();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private String getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return "";
        }

        try {
            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (location == null) {
                location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            }

            if (location != null) {
                return "https://maps.google.com/maps?q=" + location.getLatitude() + "," + location.getLongitude();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "";
    }

    private void vibrateSOS() {
        if (vibrator != null) {
            // SOS pattern: ... --- ... (short-short-short long-long-long short-short-short)
            long[] sosPattern = {0, 200, 100, 200, 100, 200, 200, 500, 100, 500, 100, 500, 200, 200, 100, 200, 100, 200};
            vibrator.vibrate(sosPattern, -1);
        }
    }

    private void updateStatus(String status) {
        if (statusTextView != null) {
            statusTextView.setText("Status: " + status);
        }
    }

    private void updateConnectedDevices(int count) {
        if (connectedDevicesTextView != null) {
            connectedDevicesTextView.setText("Connected Devices: " + count);
        }
    }

    private final BroadcastReceiver discoveryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device != null && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED) {
                    discoveredDevices.add(device);
                    String deviceName = device.getName();
                    if (deviceName == null) deviceName = "Unknown Emergency Device";
                    discoveredDevicesArrayAdapter.add(deviceName + "\n" + device.getAddress());
                }
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                updateStatus("Device scan completed - " + discoveredDevices.size() + " devices found");
                Toast.makeText(MainActivity.this, "Found " + discoveredDevices.size() + " emergency devices", Toast.LENGTH_SHORT).show();
            }
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (bluetoothService != null) {
            bluetoothService.stop();
        }
        try {
            unregisterReceiver(discoveryReceiver);
        } catch (IllegalArgumentException e) {
            // Receiver not registered
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BT && resultCode == RESULT_OK) {
            loadPairedDevices();
            updateStatus("Bluetooth enabled - Ready for emergency communication");
        }
    }
}